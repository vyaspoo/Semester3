
function onEnterPressed(event){
    if(event.key !== "Enter"){
        return;
    }

    addEntry();
}

var id=0;

function addEntry() {
    snippet = `
    <tr id="${id}">
        <td onClick="removeEntry(${id})"}>❌</td>
        <td>${getName()}</td>
    </tr>
    `
    id +=1;
    setName("");

    document.getElementById("tbody").innerHTML += snippet;
}

function removeEntry(id) {
    document.getElementById(id).remove();
}

/*taking entries as arrays and adding those to table */

var entries=[];
function refreshTable()
{
    var i,code="";
    for(i=0;i<entries.length;i++)
    {
        var row="<tr>"+"<td>"+"❌"+ "</td>"+"<td>"+ entries[i]+ "</td>"+"</tr>";
        code +=row + "\n";
    }
    document.getElementById("tbody").innerHTML =code;

    
}

function getName() {
    return document.getElementById("name").value;
}

function setName(name) {
    return document.getElementById("name").value=name;
}
